# CatClock

A beautiful sky clock app builded with [flutter](https://flutter.dev/).

> This project is submitted to [Flutter Clock challenge](https://flutter.dev/clock)

## Getting Started

```bash
cd cat_clock
flutter create .
flutter run
```

## Screenshots

| Time    | Screenshot                |
| ------- | ------------------------- |
| Morning | ![1](./screenshots/1.png) |
| Noon    | ![2](./screenshots/2.png) |
| Sunset  | ![3](./screenshots/3.png) |
| Night   | ![4](./screenshots/4.png) |

## License

CatClock is available under the MIT license. See the LICENSE file for more info.
